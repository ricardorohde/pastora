<?php

class Stripe_ApiConnectionError extends Stripe_Error
{
}
