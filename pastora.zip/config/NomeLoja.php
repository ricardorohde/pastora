<?php
include ("config.php");
echo "Pastora da Fazenda";
?>
